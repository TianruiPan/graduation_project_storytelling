settings = {
    "broker": "***",
    "topic":"tianrui_demo",
    "DB":"tianrui_demo.db",
    "client_id": "tianrui_demo",
    "openAIToken" : '***',
    "STORY_AI_ID":'***',
    "SUPERVISOR_AI_ID":'***'
}