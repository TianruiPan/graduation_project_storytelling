# Mapping from marker_id to display radius in pixels
OBJECT_RADII = {
    0: 30,
    1: 20,
    2: 50,
    3: 20,
    4: 80,
    5: 40,
    6: 60,
    7: 40,
    8: 60,
    9: 20,
    10: 40
    # Add more marker_id: radius pairs as needed
}
