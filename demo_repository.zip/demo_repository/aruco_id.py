ARUCO_ID_LABELS = {
    0: "cube",
    1: "pyramid",
    2: "UFO",
    3: "animal",
    4: "hill",
    5: "cartoon character",
    #6: "car",
    7: "hemisphere",
    8: "rocks",
    9: "cylinder",
    10: "car"
}
